public class Comum extends Usuario {
    public Comum(String nome, String login) {
        super(nome, login);
    }
}