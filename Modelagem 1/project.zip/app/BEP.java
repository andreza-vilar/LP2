package app;

public class BEP {

    private Bordado[] bordados;

    private Compra[] compra;

    public void cadastraBordado(int numeroBordado, int numeroLinha, int numeroColuna) {

    }

    public void atualizarBordado(int numeroBordado, int numeroLinha, int numeroColuna, String tipoDePonto) {

    }

    public String imprimirBordado(int numeroBordado) {

    }

    public String listarBordados() {

    }

    public void alterarTamanho(int numeroBordado, int numeroLinha, int numeroColuna) {

    }

    public void cadastraCompra(String numBordado) {

    }

    public String imprimirCompra(int numCompra) {

    }

}