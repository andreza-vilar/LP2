public abstract class Usuario {
    private String nome;
    private String login;
    private String papel;

    public Usuario(String nome, String login) {
        this.nome = nome;
        this.login = login;
        this.papel = "comum"; // Todo usuário começa com o papel comum
    }

    public String getNome() {
        return nome;
    }

    public String getLogin() {
        return login;
    }

    public String getPapel() {
        return papel;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPapel(String papel) {
        this.papel = papel;
    }
}