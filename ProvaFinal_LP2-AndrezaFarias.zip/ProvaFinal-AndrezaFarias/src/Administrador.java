public class Administrador extends Usuario {
    public Administrador(String nome, String login) {
        super(nome, login);
        setPapel("administrador");
    }
}