package app;

public class Historico {

    private String topico;

    private String email;

    private String data;

    private String ultimaAtualizacaoDaPagina;

    public Historico(String topico, String email, String data, String ultimaAtualizacaoDaPagina) {

    }

    public String toString() {

    }

}