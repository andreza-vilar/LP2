package app;

public class Compra {

    private String bordado[];

    private int precoTotal;

    public Compra([] bordado) {

    }

    public int calculaPrecoTotal(int quantidadePontos) {

    }

    public String toString() {

    }

}