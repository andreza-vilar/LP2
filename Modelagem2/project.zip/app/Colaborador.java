package app;

public class Colaborador {

    private String nome;

    private String email;

    private int atualizacoes;

    public Colaborador(String email, String nome) {

    }

    public void incrementaAtualizacao() {

    }

    public int hashCode() {

    }

    public boolean equals(object o) {

    }

    public String toString() {

    }

}