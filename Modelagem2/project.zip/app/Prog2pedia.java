package app;

public class Prog2pedia {

    private Map<String, Pagina> pagina;

    private Map<String, Colaborador> colaboradores;

    private List<Historico> historico;

    public Prog2pedia() {

    }

    public void adicionaPagina(String titulo, String emailDoColaborador) {

    }

    public void edicaoDePagina(String titulo, String emailDoColaborador, String assunto) {

    }

    public String exibirPagina(String titulo) {

    }

    public String exibirPagina() {

    }

    public void adicionarTema(String titulo, String tema) {

    }

    public String listarPaginaTema(String tema) {

    }

    public void novoColaborador(String nome, String emailDoColaborador) {

    }

    public void adicionarColaboradorEspecial(String titulo, String emailDoColaborador) {

    }

    public String exibirColaboradores() {

    }

    public void adicionarHistorico(String data, String email, String tema, String assunto) {

    }

    public void listarHistorico() {

    }

    public String exibirHistoricoEdicao() {

    }

}