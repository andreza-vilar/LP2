package app;

public class Pagina {

    private String titulo;

    private String emailDoColaborador;

    private String assunto;

    private ArrayList<Colaboradores> colaboradores;

    private HashSet<str> temas;

    public Pagina(String titulo, String emailDoColaborador) {

    }

    public void adicionarColaboradorEspecial(String emailDoColaborador) {

    }

    public void editarAPagina(colaborador Colaborador, String assunto) {

    }

    public String listarColaboradores() {

    }

    public boolean verificaTema(String tema) {

    }

    public String toString() {

    }

    public int hashCode() {

    }

    public boolean equals(object o) {

    }

}