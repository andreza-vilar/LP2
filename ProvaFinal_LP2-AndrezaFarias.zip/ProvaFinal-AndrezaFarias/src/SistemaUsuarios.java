import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SistemaUsuarios {
    private Map<String, Usuario> usuarios;
    private Map<String, Integer> numItensPorUsuario;

    public SistemaUsuarios() {
        usuarios = new HashMap<>();
        numItensPorUsuario = new HashMap<>();
    }

    public boolean cadastraUsuario(String nome, String login) {
        if (usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Login já existente: " + login);
        }

        Usuario usuario = new Comum(nome, login);
        usuarios.put(login, usuario);
        numItensPorUsuario.put(login, 0);
        return true;
    }

    public boolean alteraNomeUsuario(String login, String novoNome) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        Usuario usuario = usuarios.get(login);
        usuario.setNome(novoNome);
        return true;
    }

    public boolean removerUsuario(String login) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        usuarios.remove(login);
        numItensPorUsuario.remove(login);
        return true;
    }

    public void definirPapel(String login, String nomeNovoPapel) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        Usuario usuario = usuarios.get(login);

        if (usuario instanceof Administrador) {
            throw new IllegalArgumentException("Não é possível alterar o papel de um usuário Administrador.");
        }

        if ("administrador".equalsIgnoreCase(nomeNovoPapel)) {
            usuarios.put(login, new Administrador(usuario.getNome(), login));
        } else if ("comum".equalsIgnoreCase(nomeNovoPapel)) {
            usuarios.put(login, new Comum(usuario.getNome(), login));
        } else {
            throw new IllegalArgumentException("Papel inválido: " + nomeNovoPapel);
        }
    }

    public boolean podeAcao(String login, String acao) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        Usuario usuario = usuarios.get(login);

        if (usuario instanceof Administrador) {
            return true; // Administrador tem permissão para todas as ações
        }

        if ("criar".equalsIgnoreCase(acao) ||
                "recuperar".equalsIgnoreCase(acao) ||
                "editar".equalsIgnoreCase(acao) ||
                "apagar".equalsIgnoreCase(acao)) {
            return false; // Usuário comum não tem permissão para essas ações
        }

        return true; // Usuário comum tem permissão para outras ações
    }

    public String getDescricaoPapel(String login) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        Usuario usuario = usuarios.get(login);
        return usuario.getPapel();
    }

    public void cadastrarItemTexto(String login, String descricao, int ano, String texto, int relevancia) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        // Lógica para cadastrar um item de texto
        numItensPorUsuario.put(login, numItensPorUsuario.get(login) + 1);
    }

    public void cadastrarItemNumero(String login, String descricao, int ano, int numero) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        // Lógica para cadastrar um item numérico
        numItensPorUsuario.put(login, numItensPorUsuario.get(login) + 1);
    }

    public int getItens(String login) {
        if (!usuarios.containsKey(login)) {
            throw new IllegalArgumentException("Usuário não encontrado: " + login);
        }

        return numItensPorUsuario.get(login);
    }

    public String listaUsuariosNumItens() {
        List<Usuario> usuariosOrdenados = new ArrayList<>(usuarios.values());
        usuariosOrdenados.sort((u1, u2) -> {
            int numItensU1 = numItensPorUsuario.get(u1.getLogin());
            int numItensU2 = numItensPorUsuario.get(u2.getLogin());
            return Integer.compare(numItensU2, numItensU1); // Ordem decrescente
        });

        StringBuilder sb = new StringBuilder();
        for (Usuario usuario : usuariosOrdenados) {
            sb.append(usuario.getLogin()).append("\n");
        }

        return sb.toString();
    }

}