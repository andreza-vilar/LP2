package app;

public class Bordado {

    private int numPontos;

    private int numLinha;

    private int numColuna;

    private str [][] pontosBordados;

    public Bordado(int numLinha, int numColuna) {

    }

    public int getNumPontos() {

    }

    public int getNumLinha() {

    }

    public int getNumColuna() {

    }

    public void cadastrarPontos(int numLinha, int numColuna) {

    }

    public void alterarBordado(int numLinha, int numColuna) {

    }

    public String toString() {

    }

}