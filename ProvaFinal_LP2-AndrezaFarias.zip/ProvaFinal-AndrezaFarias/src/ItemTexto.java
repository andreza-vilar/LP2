public class ItemTexto extends Item {
    private String texto;
    private int relevancia;

    public ItemTexto(String descricao, int ano, String texto, int relevancia) {
        super(descricao, ano);
        this.texto = texto;
        this.relevancia = relevancia;
    }

    public String getTexto() {
        return texto;
    }

    public int getRelevancia() {
        return relevancia;
    }

    @Override
    public String getRepresentacao() {
        return "Item - Texto - " + texto + " - " + relevancia;
    }
}