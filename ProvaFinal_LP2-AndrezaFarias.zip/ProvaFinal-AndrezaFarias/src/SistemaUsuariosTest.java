import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SistemaUsuariosTest {
    private SistemaUsuarios sistemaUsuarios;

    @BeforeEach
    public void setup() {
        sistemaUsuarios = new SistemaUsuarios();
    }

    @Test
    public void testCadastraUsuario() {
        boolean resultado = sistemaUsuarios.cadastraUsuario("João", "joao123");
        Assertions.assertTrue(resultado);
    }

    @Test
    public void testCadastraUsuario_Duplicado() {
        sistemaUsuarios.cadastraUsuario("Maria", "maria456");

        Assertions.assertThrows(IllegalArgumentException.class, () ->
                sistemaUsuarios.cadastraUsuario("Maria", "maria456"));
    }

    @Test
    public void testAlteraNomeUsuario() {
        sistemaUsuarios.cadastraUsuario("Pedro", "pedro789");

        boolean resultado = sistemaUsuarios.alteraNomeUsuario("pedro789", "Pedro Silva");
        Assertions.assertTrue(resultado);

        Usuario usuario = sistemaUsuarios.buscarUsuarioPorLogin("pedro789");
        Assertions.assertEquals("Pedro Silva", usuario.getNome());
    }

    @Test
    public void testAlteraNomeUsuario_NaoEncontrado() {
        Assertions.assertThrows(IllegalArgumentException.class, () ->
                sistemaUsuarios.alteraNomeUsuario("inexistente", "Novo Nome"));
    }
}