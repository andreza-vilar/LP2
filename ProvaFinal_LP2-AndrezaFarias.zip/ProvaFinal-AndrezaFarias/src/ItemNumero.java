public class ItemNumero extends Item {
    private int numero;

    public ItemNumero(String descricao, int ano, int numero) {
        super(descricao, ano);
        this.numero = numero;
    }

    public int getNumero() {
        return numero;
    }

    @Override
    public String getRepresentacao() {
        return "Item - Numero - " + numero;
    }
}