public abstract class Item {
    private String descricao;
    private int ano;

    public Item(String descricao, int ano) {
        this.descricao = descricao;
        this.ano = ano;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getAno() {
        return ano;
    }

    public abstract String getRepresentacao();
}